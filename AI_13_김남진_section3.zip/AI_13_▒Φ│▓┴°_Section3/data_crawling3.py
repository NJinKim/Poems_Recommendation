from pydoc import pager
import re
from sre_constants import IN
from wsgiref import headers
import requests
from bs4 import BeautifulSoup
import sqlite3
from selenium import webdriver
import time
import pandas as pd

# sqlite3 연결
conn = sqlite3.connect('Section3_Project/poems.db', isolation_level=None)
cur = conn.cursor()

query = cur.execute("SELECT Author FROM Book2_table")
cols = [column[0] for column in query.description]
author_list = pd.DataFrame.from_records(data=query.fetchall(), columns=cols)

cur.execute("DROP TABLE IF EXISTS Dbpia_table")
cur.execute("""CREATE TABLE Dbpia_table (
    id INTEGER NOT NULL PRIMARY KEY,
    DBPia_rev INTEGER
    )
""")


URL_DBPia = 'https://www.dbpia.co.kr/'
browser = webdriver.Chrome()
browser.get(URL_DBPia)
elem = browser.find_element_by_id('keyword')
elem.click()

for author in author_list['Author']:
    time.sleep(2) 
    
    try:
        elem = browser.find_element_by_id('keyword')
        elem.clear()
        elem.click()
        elem.send_keys(author)
        
        # 논문/기사명에만 이름이 포함될 수 있게 설정 (작가가 저자로 발표한 글 제외)
        elem = browser.find_element_by_id('dev_srchOpt')
        elem.click()
        elem = browser.find_element_by_xpath('//*[@id="dev_srchOpt"]/option[2]')
        elem.click()
        elem = browser.find_element_by_class_name('btnSearch')
        elem.click()
        
        time.sleep(1)
        
        elem = browser.find_element_by_xpath('//*[@id="dev_category"]/li[1]/span/label')
        if elem.is_selected() == False:
            elem.click()

        time.sleep(1)
        
        elem = browser.find_element_by_xpath('//*[@id="contents"]/div[2]/div[2]/div[3]/div[1]/div[2]/div[2]/div[2]')
        elem.click()
        
        # 검색 결과 개수
        html = browser.page_source
        dbpia_soup = BeautifulSoup(html, 'html.parser')
        
        try:
            search_result = int(re.sub(r'[^0-9]', '', dbpia_soup.find(class_='searchCount').text))
        except:
            search_result = None
    
        insert_date3 = "INSERT INTO Dbpia_table(DBPia_rev) VALUES(?)"
        cur.execute(insert_date3, [search_result])
    
    except:
        search_result = None
        insert_date3 = "INSERT INTO Dbpia_table(DBPia_rev) VALUES(?)"
        cur.execute(insert_date3, [search_result])

browser.quit()

conn.close()

