from flask import Flask, render_template, request
# import numpy as np
# import pickle
import pandas as pd

# model = pickle.load(open('model.pkl', 'rb'))

data = pd.read_csv('csv_datafile/dataframe_processed')
data = data.sort_values(by='Sales_point', ascending=False)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def show_result():
    if request.method == 'POST':
        title = request.form["Title"]
    index_num = data.loc[data['Book_Title'] == title].index[0]
    cluster_name = data.loc[index_num, 'clusters']
    rec_book_list = data.loc[data['clusters'] == cluster_name]['Book_Title'][0:5].tolist()
    rec_author_list = data.loc[data['clusters'] == cluster_name]['Author'][0:5].tolist()
    rec_publisher_list = data.loc[data['clusters'] == cluster_name]['Publisher'][0:5].tolist()
    rec_pubdate_list = data.loc[data['clusters'] == cluster_name]['Pub_date'][0:5].tolist()
    
    rec1 = [rec_book_list[0], rec_author_list[0], rec_publisher_list[0], rec_pubdate_list[0]]
    rec2 = [rec_book_list[1], rec_author_list[1], rec_publisher_list[1], rec_pubdate_list[1]]
    rec3 = [rec_book_list[2], rec_author_list[2], rec_publisher_list[2], rec_pubdate_list[2]]
    rec4 = [rec_book_list[3], rec_author_list[3], rec_publisher_list[3], rec_pubdate_list[3]]
    rec5 = [rec_book_list[4], rec_author_list[4], rec_publisher_list[4], rec_pubdate_list[4]]
    
    result = [rec1, rec2, rec3, rec4, rec5]
    
    return render_template('result.html', result=result)
    