from pydoc import pager
import re
from sre_constants import IN
from wsgiref import headers
import requests
from bs4 import BeautifulSoup
import sqlite3

# sqlite3 연결
conn = sqlite3.connect('poems.db', isolation_level=None)

cur = conn.cursor()
cur.execute("DROP TABLE IF EXISTS Book1_table")
cur.execute("""CREATE TABLE Book1_table (
    id INTEGER NOT NULL PRIMARY KEY,
    Book_Title TEXT,
    BOOK_id INTEGER
    )
""")

URL_Aladin = 'https://www.aladin.co.kr/'

id_list = []
    
# 50개씩 보기로 하면 약 850여개의 페이지가 나오는데, 그 중 발매일 순으로 내림차순하여 200개만 사용 (10,000개)
for num in range(200):
    page_num = num + 1
    URL_List = URL_Aladin + f'shop/wbrowse.aspx?BrowseTarget=List&ViewRowsCount=50&ViewType=Detail&PublishMonth=0&SortOrder=5&page={page_num}&Stockstatus=1&PublishDay=84&CID=51167&SearchOption='

    poem_title = requests.get(URL_List)
    poem_title.raise_for_status()
    title_soup = BeautifulSoup(poem_title.content, 'html.parser')
    
    # 0~49까지 모두 가져온다...
    for i in range(50):
        
        # 책 제목
        titles = title_soup.select('li > a > b')[i].text
        #title_list.append(titles)
        
        # 알라딘 url에 부여된 책 id
        bookcode = int(title_soup.find_all(class_='bo3')[i]['href'].split('=')[-1])
        
        insert_data = "INSERT INTO Book1_table(Book_Title, BOOK_id) VALUES(?, ?)"
        cur.execute(insert_data, [titles, bookcode])

        
        
