from pydoc import pager
import re
from sre_constants import IN
from wsgiref import headers
import requests
from bs4 import BeautifulSoup
import sqlite3
import pandas as pd

# sqlite3 연결
conn = sqlite3.connect('poems.db', isolation_level=None)
cur = conn.cursor()

query = cur.execute("SELECT BOOK_id FROM Book1_table")
cols = [column[0] for column in query.description]
id_list = pd.DataFrame.from_records(data=query.fetchall(), columns=cols)

cur.execute("DROP TABLE IF EXISTS Book2_table")
cur.execute("""CREATE TABLE Book2_table (
    id INTEGER NOT NULL PRIMARY KEY,
    Author TEXT,
    Publisher TEXT,
    Pub_date TEXT,
    Price INTEGER,
    Sales_point INTEGER,
    Score FLOAT,
    Rev_100 INTEGER,
    Rev_num INTEGER,
    Page_num INTEGER,
    Weight FLOAT,
    DBPia_rev INTEGER
    )
""")

URL_Aladin = 'https://www.aladin.co.kr/'

for id in id_list['BOOK_id']:
    URL_Poems = URL_Aladin + f'/shop/wproduct.aspx?ItemId={id}'
    poem_info = requests.get(URL_Poems)
    poem_info.raise_for_status()
    info_soup = BeautifulSoup(poem_info.content, 'html.parser')
    
    try:
        author, publisher_and_date = info_soup.find(class_='Ere_sub2_title').text.split('(지은이)')
        author = author.rstrip()
        publisher = publisher_and_date[:-10]
        pub_date = publisher_and_date[-10:]
    except:
        author = None
        publisher = None
        pub_date = None
           
    price = int(info_soup.find(class_='Ritem').text[:-2].replace(',', ''))
    sales_point = int(info_soup.find(class_='Ere_fs15 Ere_ht18').find(style='display:inline-block;').select_one('strong').text.replace(',', ''))
    score = float(info_soup.find(class_='Ere_sub_pink Ere_fs16 Ere_str').text.rstrip(' '))
    rev_num = int(info_soup.find(class_="info_list Ere_fs15 Ere_ht18").find_all('a')[3].text.split(')')[0].split('(')[1])        
    rev100_num = int(info_soup.find(class_="info_list Ere_fs15 Ere_ht18").find_all('a')[2].text.split(')')[0].split('(')[1])
    
    try:
        page = int(re.sub(r'[^0-9]', '', info_soup.find(class_='conts_info_list1').text.split('쪽')[0]))
    except:
        page = None
        
    try:
        weight = int(info_soup.find(class_='conts_info_list1').text.split('g')[0].split('mm')[1])
    except:
        weight = None

    insert_data2 = "INSERT INTO Book2_table(Author, Publisher, Pub_date, Price, Sales_point, Score, Rev_100, Rev_num, Page_num, Weight) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    cur.execute(insert_data2, [author, publisher, pub_date, price, sales_point, score, rev_num, rev100_num, page, weight])
    

conn.close()